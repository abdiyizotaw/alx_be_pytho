number1 = 10
number2 = 5
print("Addition of", number1, "and", number2, "is", number1 + number2)
print("Subtraction of", number1, "and", number2, "is", number1 - number2)
print("Multiplication of", number1, "and", number2, "is", number1 * number2)
