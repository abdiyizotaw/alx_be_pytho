current_age = int(input("How old are you? "))
age_in_2050 = current_age + (2050 - 2023)
print(f"In 2050, you will be {age_in_2050} years old.")
