principal = 1000  
rate = 0.05      
time = 3          
interest = principal * rate * time
print(f"The simple interest is: {interest}")
